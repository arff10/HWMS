<?php
session_start();
include('assets/inc/config.php');
include('assets/inc/checklogin.php');
check_login();
$doc_id = $_SESSION['doc_id'];

// Query to count discharged patients
$query = "SELECT COUNT(*) AS discharged 
          FROM his_patients 
          WHERE pat_discharge_status = 'Discharged'";
$result = $mysqli->query($query);
$row = $result->fetch_assoc();
$discharged_patients = $row['discharged'];

// Query to count occupied beds by non-discharged patients
$query = "SELECT COUNT(*) AS occupied 
          FROM his_patients p 
          JOIN his_ward_beds w ON p.pat_id = w.patient_id
          WHERE p.pat_type = 'InPatient' 
          AND p.pat_discharge_status != 'Discharged'";
$result = $mysqli->query($query);
$row = $result->fetch_assoc();
$occupied_beds = $row['occupied'];

// Total beds in the ward
$total_beds = 24;  // Adjust this if the total bed count changes
$available_beds = $total_beds - $occupied_beds;

// Fetch only non-discharged InPatients and their assigned beds
$query = "SELECT p.pat_id, p.pat_fname, p.pat_date_joined, p.pat_ailment, w.bed_id 
          FROM his_patients p 
          JOIN his_ward_beds w ON p.pat_id = w.patient_id
          WHERE p.pat_type = 'InPatient' 
          AND p.pat_discharge_status != 'Discharged'";
$result = $mysqli->query($query);
$patients = [];
while ($row = $result->fetch_assoc()) {
    $patients[$row['bed_id']] = [
        'name' => $row['pat_fname'],
        'date' => $row['pat_date_joined'],
        'patient_id' => $row['pat_id'],
        'ic_number' => $row['pat_ailment']
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php'); ?>

<body>
    <div id="wrapper">
        <?php include('assets/inc/nav.php'); ?>
        <?php include('assets/inc/sidebar.php'); ?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <h4 class="page-title">Wad Kanak-Kanak</h4>

                 
                    <!-- Ward Layout -->
                    <div class="container">
                        <div class="row">
                            <?php for ($ward = 1; $ward <= 6; $ward++): ?>
                                <div class="col-md-4 mb-4">
                                    <div class="ward-container">
                                        <h5>Ward <?= $ward ?></h5>
                                        <div class="bed-row">
                                            <div class="row">
                                                <?php for ($bed = 1; $bed <= 4; $bed++): 
                                                    $bedNumber = (($ward - 1) * 4) + $bed;
                                                    $patientData = array_key_exists($bedNumber, $patients) ? $patients[$bedNumber] : null;
                                                    $patientId = $patientData ? $patientData['patient_id'] : '';
                                                ?>
                                                <div class="col-6 text-center">
                                                    <ion-icon name="bed" 
                                                            id="bed-<?= $ward ?>-<?= $bed ?>" 
                                                            class="bed-icon" 
                                                            data-patient-id="<?= $patientId ?>"
                                                            data-bed-number="<?= $bedNumber ?>">
                                                    </ion-icon>
                                                    <div class="bed-label">Bed <?= $bed ?></div>
                                                </div>
                                                <?php if ($bed == 2): ?>
                                                    </div><div class="row">
                                                <?php endif; ?>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php if ($ward % 3 == 0): ?>
                                    </div><div class="row">
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

        <script>
            const patients = <?= json_encode($patients) ?>;

            function initializeBeds() {
                document.querySelectorAll('.bed-icon').forEach(bedElement => {
                    const bedNumber = bedElement.getAttribute('data-bed-number');
                    bedElement.style.color = patients[bedNumber] ? 'red' : 'green';
                    bedElement.style.fontSize = '50px';
                    bedElement.style.margin = '10px';

                    if (patients[bedNumber]) {
                        bedElement.onmouseover = function() {
                            const patient = patients[bedNumber] || {};
                            const tooltipContent = `
                                <strong>Name:</strong> ${patient.name || 'N/A'}<br>
                                <strong>IC Number:</strong> ${patient.ic_number || 'N/A'}<br>
                                <strong>Date:</strong> ${patient.date || 'N/A'}<br>
                            `;
                            showTooltip(bedElement, tooltipContent);
                        };
                        bedElement.onmouseout = function() {
                            hideTooltip();
                        };
                    }
                });
            }

            function showTooltip(element, content) {
                hideTooltip();
                const tooltip = document.createElement('div');
                tooltip.className = 'bed-tooltip';
                tooltip.innerHTML = content;
                document.body.appendChild(tooltip);

                const rect = element.getBoundingClientRect();
                tooltip.style.top = `${rect.top - tooltip.offsetHeight - 10}px`;
                tooltip.style.left = `${rect.left + (rect.width - tooltip.offsetWidth) / 2}px`;
            }

            function hideTooltip() {
                document.querySelectorAll('.bed-tooltip').forEach(tooltip => tooltip.remove());
            }

            document.addEventListener('DOMContentLoaded', initializeBeds);
        </script>

        <style>
            .ward-container {
                border: 2px solid #007bff;
                border-radius: 8px;
                padding: 15px;
                margin-bottom: 15px;
                background-color: #f8f9fa;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }
            .bed-icon {
                font-size: 50px;
                margin: 10px;
                cursor: pointer;
                transition: all 0.3s ease;
            }
            .bed-icon:hover {
                transform: scale(1.1);
            }
            .bed-label {
                font-size: 12px;
                margin-top: -10px;
                color: #666;
            }
            .bed-tooltip {
                position: absolute;
                background: white;
                border: 1px solid #ccc;
                padding: 10px;
                border-radius: 5px;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
                z-index: 1000;
                pointer-events: none;
            }
        </style>
    </div>
</body>
</html>
