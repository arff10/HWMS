<?php
session_start();
include('assets/inc/config.php');
include('assets/inc/checklogin.php');
check_login();
$doc_id = $_SESSION['doc_id'];

// Verify CSRF token
if (!isset($_GET['csrf_token']) || $_GET['csrf_token'] !== $_SESSION['csrf_token']) {
    die('Invalid request');
}

// Process discharge
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['discharge_patient'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('CSRF token validation failed');
    }
    
    if (!isset($_GET['pat_id'])) {
        die("Patient ID is missing. Please select a patient to discharge.");
    }

    $pat_id = intval($_GET['pat_id']);
    
    // Start transaction
    $mysqli->begin_transaction();
    
    try {
        // 1. Update patient discharge status
        $pat_discharge_status = 'Discharged';
        $query = "UPDATE his_patients SET pat_discharge_status = ?, pat_type = 'Discharged' WHERE pat_id = ?";
        $stmt = $mysqli->prepare($query);
        if (!$stmt) {
            throw new Exception("Error preparing discharge query: " . $mysqli->error);
        }
        $stmt->bind_param('si', $pat_discharge_status, $pat_id);
        if (!$stmt->execute()) {
            throw new Exception("Error executing discharge query: " . $stmt->error);
        }
        
        if ($stmt->affected_rows > 0) {
            // 2. Update ward bed status if needed
            $query = "UPDATE his_ward_beds SET status = 'available', patient_id = NULL WHERE patient_id = ?";
            $stmt = $mysqli->prepare($query);
            if (!$stmt) {
                throw new Exception("Error preparing bed update query: " . $mysqli->error);
            }
            $stmt->bind_param('i', $pat_id);
            if (!$stmt->execute()) {
                throw new Exception("Error executing bed update query: " . $stmt->error);
            }
            
            // If all queries successful, commit transaction
            $mysqli->commit();
            $success = "Patient Discharged Successfully. Ward bed updated.";
            // Redirect after successful discharge
            header("refresh:2;url=his_doc_discharge.php");
        } else {
            throw new Exception("No patient record was updated. Please verify the patient information.");
        }
    } catch (Exception $e) {
        // If any error occurs, rollback the transaction
        $mysqli->rollback();
        $err = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<?php include('assets/inc/head.php');?>

<body>
    <div id="wrapper">
        <?php include("assets/inc/nav.php");?>
        <?php include("assets/inc/sidebar.php");?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <!-- Page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="his_doc_dashboard.php">Dashboard</a></li>
                                        <li class="breadcrumb-item"><a href="his_doc_discharge.php">Discharge</a></li>
                                        <li class="breadcrumb-item active">Patient Discharge</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Discharge Patient</h4>
                            </div>
                        </div>
                    </div>
 
                    <?php
                    if (isset($_GET['pat_id'])) {
                        $pat_id = intval($_GET['pat_id']);
                        
                        $ret = "SELECT * FROM his_patients WHERE pat_id = ?";
                        $stmt = $mysqli->prepare($ret);
                        $stmt->bind_param('i', $pat_id);
                        $stmt->execute();
                        $res = $stmt->get_result();
                        
                        if ($row = $res->fetch_object()) {
                    ?>
                            <div class="row">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h4 class="header-title">Patient Discharge Form</h4>

                                            <!-- Success/Error alerts -->
                                            <?php if (isset($success)) { ?>
                                                <div class="alert alert-success">
                                                    <?php echo $success; ?>
                                                </div>
                                            <?php } elseif (isset($err)) { ?>
                                                <div class="alert alert-danger">
                                                    <?php echo $err; ?>
                                                </div>
                                            <?php } ?>

                                            <form method="POST">
                                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                                
                                                <div class="form-row">
                                                    <div class="form-group col-md-6">
                                                        <label for="firstName" class="col-form-label">First Name</label>
                                                        <input type="text" class="form-control" 
                                                            value="<?php echo htmlspecialchars($row->pat_fname); ?>" disabled>
                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label for="lastName" class="col-form-label">Last Name</label>
                                                        <input type="text" class="form-control" 
                                                            value="<?php echo htmlspecialchars($row->pat_lname); ?>" disabled>
                                                    </div>
                                                </div>

                                                <div class="form-row">
                                                    <div class="form-group col-md-6">
                                                        <label for="patientNumber" class="col-form-label">Patient Number</label>
                                                        <input type="text" class="form-control" 
                                                            value="<?php echo htmlspecialchars($row->pat_number); ?>" disabled>
                                                    </div>
                                                    <div class="form-group col-md-6">
                                                        <label for="address" class="col-form-label">Address</label>
                                                        <input type="text" class="form-control" 
                                                            value="<?php echo htmlspecialchars($row->pat_addr); ?>" disabled>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <button type="submit" name="discharge_patient" class="btn btn-success">
                                                        Confirm Discharge
                                                    </button>
                                                    <a href="his_doc_discharge_patient.php" class="btn btn-danger">Cancel</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <?php
                        } else {
                            echo "<div class='alert alert-warning'>Patient not found.</div>";
                        }
                    } else {
                        echo "<div class='alert alert-danger'>No patient selected for discharge.</div>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>
</html>