<?php
session_start();
include('assets/inc/config.php');
include('assets/inc/checklogin.php');
check_login();
$doc_id = $_SESSION['doc_id'];
$doc_number = $_SESSION['doc_number'];

$total_beds = 24; // Total number of beds

// Query to get the total number of inpatients (occupied beds)
$result = "SELECT COUNT(*) FROM his_patients WHERE pat_type = 'InPatient'";
$stmt = $mysqli->prepare($result);
$stmt->execute();
$stmt->bind_result($occupied_beds);
$stmt->fetch();
$stmt->close();

// Query to get the number of discharged patients
$discharged_result = "SELECT COUNT(*) FROM his_patients WHERE pat_discharge_status = 'Discharged'";
$stmt = $mysqli->prepare($discharged_result);
$stmt->execute();
$stmt->bind_result($discharged_count);
$stmt->fetch();
$stmt->close();

// Calculate available beds
$available_beds = $total_beds - $occupied_beds;
?>

<!DOCTYPE html>
<html lang="en">
<?php include("assets/inc/head.php"); ?>

<body>
    <div id="wrapper">
        <?php include('assets/inc/nav.php'); ?>
        <?php include('assets/inc/sidebar.php'); ?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Dashboard Wad Kanak-Kanak</h4>
                            </div>
                        </div>
                    </div>

                    <!-- Dashboard Statistics -->
                    <div class="row">
                        <div class="col-md-6 col-xl-3">
                            <div class="widget-rounded-circle card-box">
                                <div class="row">
                                    <div class="col-6">
                                        <div class="avatar-lg rounded-circle bg-soft-danger border-danger border d-flex justify-content-center align-items-center">
                                            <i class="fab fa-accessible-icon font-22 avatar-title text-danger"></i>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="text-right">
                                            <h3 class="text-dark mt-1"><span data-plugin="counterup"><?php echo $occupied_beds; ?></span></h3>
                                            <p class="text-muted mb-1 text-truncate">Occupied Beds</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3">
                            <div class="widget-rounded-circle card-box">
                                <div class="row">
                                    <div class="col-6">
                                        <div class="avatar-lg rounded-circle bg-soft-primary border-primary border d-flex justify-content-center align-items-center">
                                            <i class="fas fa-bed text-primary" style="font-size: 24px;"></i>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="text-right">
                                            <h3 class="text-dark mt-1"><span data-plugin="counterup"><?php echo $available_beds; ?></span></h3>
                                            <p class="text-muted mb-1 text-truncate">Available Beds</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3">
                            <div class="widget-rounded-circle card-box">
                                <div class="row">
                                    <div class="col-6">
                                        <div class="avatar-lg rounded-circle bg-soft-info border-info border d-flex justify-content-center align-items-center">
                                            <i class="fas fa-procedures text-info" style="font-size: 24px;"></i>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="text-right">
                                            <h3 class="text-dark mt-1"><span data-plugin="counterup"><?php echo $total_beds; ?></span></h3>
                                            <p class="text-muted mb-1 text-truncate">Total Beds</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3">
                            <div class="widget-rounded-circle card-box">
                                <div class="row">
                                    <div class="col-6">
                                        <div class="avatar-lg rounded-circle bg-soft-danger border-danger border d-flex justify-content-center align-items-center">
                                            <i class="mdi mdi-exit-to-app font-22 avatar-title text-danger"></i>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="text-right">
                                            <h3 class="text-dark mt-1"><span data-plugin="counterup"><?php echo $discharged_count; ?></span></h3>
                                            <p class="text-muted mb-1 text-truncate">Discharged</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                  

                    <!-- Patients Table -->
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card-box">
                                <h4 class="header-title mb-3">Patients</h4>
                                <div class="table-responsive">
                                    <table class="table table-borderless table-hover table-centered m-0">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>Name</th>
                                                <th>Address</th>
                                                <th>Mobile Phone</th>
                                                <th>Category</th>
                                                <th>IC Number</th>
                                                <th>Age</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <?php
                                        $ret = "SELECT * FROM his_patients ORDER BY RAND() LIMIT 100";
                                        $stmt = $mysqli->prepare($ret);
                                        $stmt->execute();
                                        $res = $stmt->get_result();
                                        while ($row = $res->fetch_object()) {
                                        ?>
                                            <tbody>
                                                <tr>
                                                    <td><?php echo $row->pat_fname . ' ' . $row->pat_lname; ?></td>
                                                    <td><?php echo $row->pat_addr; ?></td>
                                                    <td><?php echo $row->pat_phone; ?></td>
                                                    <td><?php echo $row->pat_type; ?></td>
                                                    <td><?php echo $row->pat_ailment; ?></td>
                                                    <td><?php echo $row->pat_age; ?> Years</td>
                                                    <td>
                                                        <a href="his_doc_view_single_patient.php?pat_id=<?php echo $row->pat_id; ?>&&pat_number=<?php echo $row->pat_number; ?>&&pat_name=<?php echo $row->pat_fname; ?>_<?php echo $row->pat_lname; ?>" class="btn btn-xs btn-success">
                                                            <i class="mdi mdi-eye"></i> View
                                                        </a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        <?php } ?>
                                    </table>
                                </div>
                            </div>
                        </div> <!-- end col -->
                    </div>
                    <!-- End Patients Table -->
                </div> <!-- container -->
            </div> <!-- content -->
        </div> <!-- content-page -->
    </div> <!-- wrapper -->

    <!-- Vendor js -->
    <script src="assets/js/vendor.min.js"></script>
    <!-- App js -->
    <script src="assets/js/app.min.js"></script>
</body>
</html>
