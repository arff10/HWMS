<?php
session_start();
include('assets/inc/config.php');

if (isset($_POST['add_patient'])) {
    $pat_fname = $_POST['pat_fname'];
    $pat_lname = $_POST['pat_lname'];
    $pat_number = $_POST['pat_number'];
    $pat_phone = $_POST['pat_phone'];
    $pat_type = $_POST['pat_type'];
    $pat_addr = $_POST['pat_addr'];
    $pat_age = $_POST['pat_age'];
    $pat_dob = $_POST['pat_dob'];
    $pat_ailment = $_POST['pat_ailment'];

    // Check for available bed
    $bedQuery = "SELECT bed_id FROM his_ward_beds WHERE patient_id IS NULL LIMIT 1"; // Assuming patient_id is NULL for available beds
    $bedResult = $mysqli->query($bedQuery);

    if ($bedResult->num_rows > 0) {
        $bed = $bedResult->fetch_assoc();
        $assigned_bed_id = $bed['bed_id'];

        // SQL query to insert captured values
        $query = "INSERT INTO his_patients 
                  (pat_fname, pat_ailment, pat_lname, pat_age, pat_dob, pat_number, pat_phone, pat_type, pat_addr) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('sssssssss', 
            $pat_fname, $pat_ailment, $pat_lname, 
            $pat_age, $pat_dob, $pat_number, 
            $pat_phone, $pat_type, $pat_addr);
        $stmt->execute();

        // Get the last inserted patient ID
        $new_patient_id = $stmt->insert_id; // Get the ID of the newly inserted patient

        // Update the bed record to assign the patient to the bed
        $updateBedQuery = "UPDATE his_ward_beds SET patient_id = ? WHERE bed_id = ?";
        $updateBedStmt = $mysqli->prepare($updateBedQuery);
        $updateBedStmt->bind_param('si', $new_patient_id, $assigned_bed_id); // Bind the new patient ID
        $updateBedStmt->execute();

        // SweetAlert feedback for success or failure
        if ($stmt && $updateBedStmt) {
            $success = "Patient details added successfully and assigned to Bed ID: $assigned_bed_id!";
        } else {
            $err = "An error occurred. Please try again later.";
        }
    } else {
        $err = "No available beds at the moment.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include('assets/inc/head.php'); ?>

<body>
    <!-- Begin page -->
    <div id="wrapper">

        <!-- Topbar Start -->
        <?php include("assets/inc/nav.php"); ?>
        <?php include("assets/inc/sidebar.php"); ?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="his_doc_dashboard.php">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item">
                                            <a href="#">Patients</a>
                                        </li>
                                        <li class="breadcrumb-item active">Add Patient</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Add Patient Details</h4>
                            </div>
                        </div>
                    </div>     

                    <!-- Form row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">Fill all fields</h4>

                                    <!-- Patient Registration Form -->
                                    <form method="post">
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="pat_fname" class="col-form-label">First Name</label>
                                                <input type="text" required name="pat_fname" class="form-control" placeholder="Patient's First Name">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="pat_lname" class="col-form-label">Last Name</label>
                                                <input type="text" required name="pat_lname" class="form-control" placeholder="Patient's Last Name">
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="pat_dob" class="col-form-label">Date of Birth</label>
                                                <input type="text" required name="pat_dob" class="form-control" placeholder="DD/MM/YYYY">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="pat_age" class="col-form-label">Age</label>
                                                <input type="number" required name="pat_age" class="form-control" placeholder="Patient's Age" min="0">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="pat_addr" class="col-form-label">Address</label>
                                            <input type="text" required name="pat_addr" class="form-control" placeholder="Patient's Address">
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-md-4">
                                                <label for="pat_phone" class="col-form-label">Mobile Number</label>
                                                <input type="text" required name="pat_phone" class="form-control" placeholder="Mobile Number">
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="pat_ailment" class="col-form-label">Patient IC Number</label>
                                                <input type="text" required name="pat_ailment" class="form-control" placeholder="IC Number">
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="pat_type" class="col-form-label">Patient Type</label>
                                                <select name="pat_type" required class="form-control">
                                                    <option value="">Choose</option>
                                                    <option value="InPatient">InPatient</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group" style="display: none;">
                                            <?php 
                                                $length = 5;    
                                                $patient_number = substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 1, $length);
                                            ?>
                                            <label for="pat_number" class="col-form-label">Patient Number</label>
                                            <input type="text" name="pat_number" value="<?php echo $patient_number; ?>" class="form-control">
                                        </div>

                                        <button type="submit" name="add_patient" class="btn btn-primary">Add Patient</button>
                                    </form>
                                    <!-- End Patient Form -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- container -->
            </div> <!-- content -->
        </div> <!-- content-page -->

    </div> <!-- wrapper -->

    <!-- Right bar overlay -->
    <div class="rightbar-overlay"></div>

    <!-- Vendor JS -->
    <script src="assets/js/vendor.min.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.min.js"></script>

    <!-- SweetAlert JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Alert Initialization -->
    <script>
        <?php if (isset($success)) { ?>
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '<?php echo $success; ?>',
                showConfirmButton: false,
                timer: 2000
            });
        <?php } elseif (isset($err)) { ?>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: '<?php echo $err; ?>',
            });
        <?php } ?>
    </script>

</body>
</html>
