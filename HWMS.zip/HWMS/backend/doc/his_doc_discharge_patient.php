<?php
session_start();
include('assets/inc/config.php');
include('assets/inc/checklogin.php');
check_login();
$doc_id = $_SESSION['doc_id'];

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>

<!DOCTYPE html>
<html lang="en">
    
<?php include('assets/inc/head.php');?>

<body>
    <div id="wrapper">
        <?php include('assets/inc/nav.php');?>
        <?php include("assets/inc/sidebar.php");?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <!-- Page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Patients</a></li>
                                        <li class="breadcrumb-item active">Discharge Patients</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Discharge Patients</h4>
                            </div>
                        </div>
                    </div>     

                    <div class="row">
                        <div class="col-12">
                            <div class="card-box">
                                <h4 class="header-title">Patients Ready for Discharge</h4>
                                <div class="mb-2">
                                    <div class="row">
                                        <div class="col-12 text-sm-center form-inline" >
                                            <div class="form-group">
                                                <input id="demo-foo-search" type="text" placeholder="Search" 
                                                    class="form-control form-control-sm" autocomplete="on">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="table-responsive">
                                    <table id="demo-foo-filtering" class="table table-bordered toggle-circle mb-0" 
                                        data-page-size="7">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th data-toggle="true">Patient Name</th>
                                                <th data-hide="phone">Patient Number</th>
                                                <th data-hide="phone">Patient Address</th>
                                                <th data-hide="phone">Patient Category</th>
                                                <th data-hide="phone">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $ret = "SELECT * FROM his_patients WHERE pat_discharge_status != 'Discharged' 
                                                    AND pat_type = 'InPatient'";
                                            $stmt = $mysqli->prepare($ret);
                                            if (!$stmt) {
                                                die("Error in prepare: " . $mysqli->error);
                                            }
                                            if (!$stmt->execute()) {
                                                die("Error in execute: " . $stmt->error);
                                            }
                                            $res = $stmt->get_result();
                                            if (!$res) {
                                                die("Error getting result: " . $stmt->error);
                                            }
                                            
                                            $cnt = 1;
                                            while ($row = $res->fetch_object()) {
                                            ?>
                                                <tr>
                                                    <td><?php echo $cnt;?></td>
                                                    <td><?php echo htmlspecialchars($row->pat_fname . ' ' . $row->pat_lname);?></td>
                                                    <td><?php echo htmlspecialchars($row->pat_number);?></td>
                                                    <td><?php echo htmlspecialchars($row->pat_addr);?></td>
                                                    <td><?php echo htmlspecialchars($row->pat_type);?></td>
                                                    <td>
                                                        <a href="his_doc_discharge_single_patient.php?pat_id=<?php echo urlencode($row->pat_id); ?>&csrf_token=<?php echo urlencode($_SESSION['csrf_token']); ?>" 
                                                           class="badge badge-primary">
                                                            <i class="mdi mdi-check-box-outline"></i> Discharge
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php  
                                            $cnt++;
                                            }
                                            ?>
                                        </tbody>
                                        <tfoot>
                                            <tr class="active">
                                                <td colspan="8">
                                                    <div class="text-right">
                                                        <ul class="pagination pagination-rounded justify-content-end footable-pagination m-t-10 mb-0"></ul>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div> 
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="rightbar-overlay"></div>

    <!-- Scripts -->
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/libs/footable/footable.all.min.js"></script>
    <script src="assets/js/pages/foo-tables.init.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>
</html>