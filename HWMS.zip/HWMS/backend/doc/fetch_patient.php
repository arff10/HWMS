<?php
session_start();
include('assets/inc/config.php'); // Include database connection file

if (isset($_GET['id'])) {
    // Get the patient ID from the request and sanitize it
    $patientId = intval($_GET['id']); 

    // Prepare the SQL query to fetch patient data
    $query = "SELECT pat_id, pat_fname AS name, pat_condition AS condition, pat_notes AS notes FROM his_patients WHERE pat_id = ?";
    
    if ($stmt = $mysqli->prepare($query)) {
        // Bind the patient ID to the prepared statement
        $stmt->bind_param("i", $patientId);
        
        // Execute the query
        $stmt->execute();
        
        // Get the result
        $result = $stmt->get_result();
        
        // Check if a patient was found
        if ($result->num_rows > 0) {
            // Fetch patient data as an associative array
            $patient = $result->fetch_assoc(); 
            echo json_encode($patient); // Return data as JSON
        } else {
            echo json_encode(['error' => 'Patient not found']); // Patient not found
        }

        // Close the statement
        $stmt->close(); 
    } else {
        echo json_encode(['error' => 'Database query preparation failed']); // Query preparation failed
    }
} else {
    echo json_encode(['error' => 'No patient ID provided']); // No ID provided in request
}

// Close the database connection
$mysqli->close();
?>
